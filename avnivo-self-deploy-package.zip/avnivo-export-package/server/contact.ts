import { createHmac } from "node:crypto";
import { and, count, desc, eq, gt } from "drizzle-orm";
import { nanoid } from "nanoid";
import { z } from "zod";
import { contactInquiries } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { notifyOwner } from "./_core/notification";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";

export const contactServiceOptions = [
  "Web experiences",
  "Brand systems",
  "AI-native craft",
  "Automation systems",
  "Product strategy",
  "Creative solutions",
  "Not sure yet",
] as const;

export const contactInquiryInput = z.object({
  name: z.string().trim().min(2, "Please enter your name.").max(120, "Name is too long."),
  email: z.string().trim().email("Please enter a valid email address.").max(320, "Email is too long."),
  company: z.string().trim().max(160, "Company name is too long.").optional().default(""),
  service: z.enum(contactServiceOptions),
  message: z.string().trim().min(20, "Please share a little more about the project.").max(5000, "Message is too long."),
  website: z.string().max(200).optional().default(""),
});

export type ContactInquiryInput = z.infer<typeof contactInquiryInput>;

const CONTACT_NOTIFICATION_SENDER = "AVNIVO-CREATIVE DIGITAL&AI STUDIO";
const CONTACT_NOTIFICATION_SUBJECT = "new website lead from form submission";

const RATE_WINDOW_MS = 60 * 60 * 1000;
const MAX_PER_IP_AND_EMAIL_PER_WINDOW = 3;
const MAX_PER_IP_PER_WINDOW = 12;
const rateLimitCache = new Map<string, { count: number; resetAt: number }>();

type ContactRequest = {
  headers: Record<string, string | string[] | undefined>;
  socket?: { remoteAddress?: string };
};

function normalizeIp(req: ContactRequest) {
  const forwarded = req.headers["x-forwarded-for"];
  const firstForwarded = Array.isArray(forwarded) ? forwarded[0] : forwarded?.split(",")[0];
  return (firstForwarded || req.headers["x-real-ip"] || req.socket?.remoteAddress || "unknown").toString().trim();
}

function hashKey(value: string) {
  const secret = ENV.cookieSecret || "avnivo-contact-rate-limit";
  return createHmac("sha256", secret).update(value).digest("hex");
}

function consumeMemoryRateLimit(key: string, max: number) {
  const now = Date.now();
  if (rateLimitCache.size > 5000) {
    for (const [cacheKey, value] of rateLimitCache) {
      if (value.resetAt <= now) rateLimitCache.delete(cacheKey);
    }
  }
  const existing = rateLimitCache.get(key);
  if (!existing || existing.resetAt <= now) {
    rateLimitCache.set(key, { count: 1, resetAt: now + RATE_WINDOW_MS });
    return;
  }
  if (existing.count >= max) {
    throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Please wait a little before sending another message." });
  }
  existing.count += 1;
}

function assertSameSiteRequest(req: ContactRequest) {
  const origin = req.headers.origin;
  const referer = req.headers.referer;
  if (!origin || !referer) return;
  try {
    if (new URL(origin.toString()).origin !== new URL(referer.toString()).origin) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Request origin could not be verified." });
    }
  } catch (error) {
    if (error instanceof TRPCError) throw error;
    throw new TRPCError({ code: "FORBIDDEN", message: "Request origin could not be verified." });
  }
}

function fakeAcceptedResponse() {
  return { accepted: true as const, referenceCode: null, spam: true as const };
}

export async function createContactInquiry(input: ContactInquiryInput, req: ContactRequest) {
  assertSameSiteRequest(req);

  // Honeypot submissions are acknowledged without persistence so automated senders
  // cannot learn which protection stopped them.
  if (input.website.trim()) return fakeAcceptedResponse();

  const ipHash = hashKey(normalizeIp(req));
  const email = input.email.toLowerCase();
  consumeMemoryRateLimit(`${ipHash}:${hashKey(email)}`, MAX_PER_IP_AND_EMAIL_PER_WINDOW);
  consumeMemoryRateLimit(ipHash, MAX_PER_IP_PER_WINDOW);

  const db = await getDb();
  if (!db) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "The inquiry service is temporarily unavailable." });
  }

  const windowStart = new Date(Date.now() - RATE_WINDOW_MS);
  const recent = await db
    .select({ total: count() })
    .from(contactInquiries)
    .where(and(eq(contactInquiries.ipHash, ipHash), gt(contactInquiries.createdAt, windowStart)));

  if (Number(recent[0]?.total ?? 0) >= MAX_PER_IP_PER_WINDOW) {
    throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Please wait a little before sending another message." });
  }

  const referenceCode = `AVN-${nanoid(8).toUpperCase()}`;
  await db.insert(contactInquiries).values({
    referenceCode,
    name: input.name,
    email,
    company: input.company || null,
    service: input.service,
    message: input.message,
    source: "website",
    ipHash,
  });

  void notifyOwner({
    title: CONTACT_NOTIFICATION_SUBJECT,
    content: [
      `From: ${CONTACT_NOTIFICATION_SENDER}`,
      `Reference: ${referenceCode}`,
      `Name: ${input.name}`,
      `Email: ${email}`,
      `Company: ${input.company || "—"}`,
      `Service: ${input.service}`,
      `Message: ${input.message}`,
    ].join("\n"),
  }).catch(error => {
    console.warn("[Contact] Owner notification failed:", error instanceof Error ? error.message : "unknown error");
  });

  return { accepted: true as const, referenceCode, spam: false as const };
}

export async function listContactInquiries(limit: number) {
  const db = await getDb();
  if (!db) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "The inquiry service is temporarily unavailable." });
  }
  return db
    .select({
      id: contactInquiries.id,
      referenceCode: contactInquiries.referenceCode,
      name: contactInquiries.name,
      email: contactInquiries.email,
      company: contactInquiries.company,
      service: contactInquiries.service,
      message: contactInquiries.message,
      status: contactInquiries.status,
      source: contactInquiries.source,
      createdAt: contactInquiries.createdAt,
      updatedAt: contactInquiries.updatedAt,
    })
    .from(contactInquiries)
    .orderBy(desc(contactInquiries.createdAt))
    .limit(limit);
}
