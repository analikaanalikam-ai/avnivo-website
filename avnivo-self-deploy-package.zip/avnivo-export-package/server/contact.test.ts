import { describe, expect, it } from "vitest";
import { contactInquiryInput } from "./contact";

describe("contact inquiry validation", () => {
  it("accepts a complete project inquiry", () => {
    const result = contactInquiryInput.safeParse({
      name: "Ava Morgan",
      email: "ava@example.com",
      company: "Northstar",
      service: "Web experiences",
      message: "We need a new digital home for an ambitious product launch.",
      website: "",
    });
    expect(result.success).toBe(true);
  });

  it("rejects malformed input and short messages", () => {
    const result = contactInquiryInput.safeParse({
      name: "A",
      email: "not-an-email",
      service: "Web experiences",
      message: "Too short",
    });
    expect(result.success).toBe(false);
  });

  it("accepts the honeypot field without changing the public shape", () => {
    const result = contactInquiryInput.parse({
      name: "Automation",
      email: "bot@example.com",
      service: "Not sure yet",
      message: "This is a long enough message for the schema to accept it.",
      website: "https://spam.example",
    });
    expect(result.website).toBe("https://spam.example");
  });
});
