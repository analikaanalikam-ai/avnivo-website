import { useEffect, useState, type FormEvent } from "react";
import { ArrowUpRight, MoveUpRight, Plus, Sparkles } from "lucide-react";
import { trpc } from "@/lib/trpc";

const portfolio = [
  {
    number: "01",
    eyebrow: "WEB DEVELOPMENT",
    title: "Interfaces with presence.",
    description: "Immersive digital products shaped around clarity, rhythm, and the moments that make a brand feel alive.",
    image: "/assets/avnivo-2.webp",
    alt: "Graphite desktop monitor and laptop displaying a premium dark-mode website interface",
    className: "work-card--wide",
  },
  {
    number: "02",
    eyebrow: "GRAPHIC DESIGN",
    title: "Identity, made tangible.",
    description: "Brand systems with the weight, restraint, and detail to move from screen to space.",
    image: "/assets/avnivo-3.webp",
    alt: "Charcoal stationery, poster and glass swatch board arranged as a premium identity system",
    className: "work-card--tall",
  },
  {
    number: "03",
    eyebrow: "AI-POWERED DESIGN",
    title: "Intelligence, composed.",
    description: "New creative directions built with considered systems—not shortcuts, noise, or borrowed tropes.",
    image: "/assets/avnivo-4.webp",
    alt: "Abstract glass neural lattice orbiting a polished dark metal core",
    className: "work-card--tall work-card--offset",
  },
  {
    number: "04",
    eyebrow: "CREATIVE SOLUTIONS",
    title: "From spark to system.",
    description: "A sharper path from a first idea to a digital world that holds together at every scale.",
    image: "/assets/avnivo-5.webp",
    alt: "Floating glass panels and mobile interface connected by a luminous violet line",
    className: "work-card--wide work-card--bottom",
  },
];

const serviceOptions = [
  "Web experiences",
  "Brand systems",
  "AI-native craft",
  "Automation systems",
  "Product strategy",
  "Creative solutions",
  "Not sure yet",
] as const;
type Service = (typeof serviceOptions)[number];

const services: Array<[string, string, string, Service]> = [
  ["01", "Web experiences", "Websites, product interfaces, and digital homes that feel precise from the first frame.", "Web experiences"],
  ["02", "Brand systems", "Identity direction, art direction, and visual tools that make a point of view unmistakable.", "Brand systems"],
  ["03", "AI-native craft", "Thoughtful AI integration for teams who want more range without losing taste.", "AI-native craft"],
  ["04", "Automation systems", "Connected workflows that remove friction, surface insight, and give good teams more room to think.", "Automation systems"],
  ["05", "Product strategy", "A clear path from opportunity to useful digital product, with the right story and system underneath.", "Product strategy"],
];

type InquiryForm = {
  name: string;
  email: string;
  company: string;
  service: Service;
  message: string;
  website: string;
};

const emptyForm: InquiryForm = {
  name: "",
  email: "",
  company: "",
  service: "Not sure yet",
  message: "",
  website: "",
};

export default function Home() {
  const [form, setForm] = useState<InquiryForm>(emptyForm);
  const [submitState, setSubmitState] = useState<"idle" | "success" | "error">("idle");
  const [referenceCode, setReferenceCode] = useState<string | null>(null);

  useEffect(() => {
    const image = document.querySelector<HTMLElement>(".creative-systems-motion");
    const hero = document.querySelector<HTMLElement>(".hero");
    const glow = document.querySelector<HTMLElement>(".hero-orbit-glow");
    const grid = document.querySelector<HTMLElement>(".hero-grid");
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

    if (!image || !hero || reduceMotion.matches) return;

    const intensity = 16; // Increase up to 20 for a stronger premium offset.
    const ease = 0.055; // Lower values make the movement slower and softer.
    let targetX = 0;
    let targetY = 0;
    let targetScroll = 0;
    let currentX = 0;
    let currentY = 0;
    let currentScroll = 0;
    let frame = 0;

    const animate = () => {
      currentX += (targetX - currentX) * ease;
      currentY += (targetY - currentY) * ease;
      currentScroll += (targetScroll - currentScroll) * ease;
      image.style.transform = `translate3d(${currentX.toFixed(2)}px, ${(currentY - currentScroll * 18).toFixed(2)}px, 0) scale(${(1.035 + currentScroll * 0.025).toFixed(3)}) rotateZ(${(currentScroll * 0.8).toFixed(2)}deg)`;
      if (glow) glow.style.transform = `translate(-50%, calc(-50% + ${(currentScroll * 24).toFixed(2)}px)) scale(${(1 + currentScroll * 0.08).toFixed(3)})`;
      if (grid) grid.style.transform = `translate3d(0, ${(currentScroll * 28).toFixed(2)}px, 0)`;

      if (Math.abs(targetX - currentX) > 0.01 || Math.abs(targetY - currentY) > 0.01 || Math.abs(targetScroll - currentScroll) > 0.001) {
        frame = requestAnimationFrame(animate);
      } else {
        frame = 0;
      }
    };

    const requestAnimation = () => {
      if (!frame) frame = requestAnimationFrame(animate);
    };

    const handlePointerMove = (event: PointerEvent) => {
      targetX = -((event.clientX / window.innerWidth) - 0.5) * intensity;
      targetY = -((event.clientY / window.innerHeight) - 0.5) * intensity;
      requestAnimation();
    };

    const handleScroll = () => {
      const progress = Math.max(0, Math.min(1.15, -hero.getBoundingClientRect().top / hero.offsetHeight));
      targetScroll = progress;
      requestAnimation();
    };

    const reset = () => {
      targetX = 0;
      targetY = 0;
      requestAnimation();
    };

    image.style.willChange = "transform";
    image.style.transition = "transform 0.4s ease-out";
    if (glow) glow.style.willChange = "transform";
    if (grid) grid.style.willChange = "transform";
    window.addEventListener("pointermove", handlePointerMove, { passive: true });
    window.addEventListener("pointerleave", reset, { passive: true });
    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("pointerleave", reset);
      window.removeEventListener("scroll", handleScroll);
      if (frame) cancelAnimationFrame(frame);
      image.style.transform = "";
      image.style.willChange = "";
      image.style.transition = "";
      if (glow) {
        glow.style.transform = "";
        glow.style.willChange = "";
      }
      if (grid) {
        grid.style.transform = "";
        grid.style.willChange = "";
      }
    };
  }, []);

  useEffect(() => {
    const sections = [...document.querySelectorAll<HTMLElement>(".reveal-on-scroll")];
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

    if (reduceMotion.matches) {
      sections.forEach(section => section.classList.add("is-visible"));
      return;
    }

    const observer = new IntersectionObserver(
      entries => entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      }),
      { threshold: 0.08, rootMargin: "0px 0px -8%" },
    );

    sections.forEach(section => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  const submitInquiry = trpc.contact.submit.useMutation({
    onSuccess: result => {
      setSubmitState("success");
      setReferenceCode(result.referenceCode);
      setForm(emptyForm);
    },
    onError: () => {
      setSubmitState("error");
    },
  });

  const setField = <K extends keyof InquiryForm>(field: K, value: InquiryForm[K]) => {
    setForm(previous => ({ ...previous, [field]: value }));
    if (submitState !== "idle") setSubmitState("idle");
  };

  const selectService = (service: Service) => {
    setField("service", service);
    document.getElementById("contact-form")?.scrollIntoView({ behavior: "smooth", block: "center" });
    window.setTimeout(() => document.getElementById("contact-name")?.focus(), 500);
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    submitInquiry.mutate(form);
  };

  return (
    <div className="avnivo-site">
      <div className="site-noise" aria-hidden="true" />
        <header className="avnivo-nav">
          <a className="wordmark" href="#top" aria-label="AVNIVO home">
            <span className="wordmark-mark" aria-hidden="true"><span /><span /><span /></span>
            <span className="wordmark-name">AVNIVO</span>
            <span className="wordmark-detail">Creative digital &amp; AI studio</span>
          </a>
          <nav className="nav-links" aria-label="Primary navigation">
            <a href="#about">About</a>
            <a href="#work">Selected work</a>
            <a href="#services">Capabilities</a>
            <a href="#why">Why AVNIVO</a>
            <a href="#contact">Contact</a>
          </nav>
        <a className="nav-pulse" href="#contact">
          <span className="pulse-dot" />
          Start a conversation
          <ArrowUpRight size={15} strokeWidth={1.7} />
        </a>
      </header>

      <main>
        <section className="hero" id="top">
          <div className="hero-grid" aria-hidden="true" />
          <div className="hero-copy">
            <p className="eyebrow hero-eyebrow"><span className="eyebrow-line" /> Independent creative technology studio</p>
            <h1>Digital worlds,<br /><em>built to move.</em></h1>
            <p className="hero-intro">AVNIVO is a creative technology studio building high-performance websites, AI-native products, and intelligent systems for ambitious teams.</p>
            <div className="hero-actions">
              <a className="button button--primary" href="#work">Explore the work <MoveUpRight size={16} /></a>
              <a className="button button--quiet" href="#contact">Tell us what you&apos;re building <ArrowUpRight size={16} /></a>
            </div>
          </div>
          <div className="hero-art" aria-label="Abstract graphite glass orbit sculpture">
            <div className="hero-orbit-glow" />
            <img className="creative-systems-motion" src="/assets/avnivo-1.webp" alt="Abstract smoked glass orbit sculpture with a violet luminous ring" />
            <div className="hero-art-caption"><span>01 / 04</span><span>Creative systems in motion</span></div>
          </div>
          <div className="hero-footer"><span>Scroll to discover</span><span className="scroll-line" /><span>EST. 2024 — GLOBAL</span></div>
        </section>

        <section className="statement section-shell reveal-on-scroll" id="about">
          <div className="statement-index">A<span>—</span>01</div>
          <div className="statement-copy">
            <p className="eyebrow">About AVNIVO</p>
            <h2>Good work should feel <span>inevitable.</span></h2>
            <p className="statement-body">AVNIVO brings creative direction, product thinking, and engineering discipline into one focused studio. We turn complex ideas into clear digital experiences, practical AI systems, and brands people can trust.</p>
            <div className="about-proof" aria-label="AVNIVO studio principles">
              <div><strong>01</strong><span>Strategy before spectacle</span></div>
              <div><strong>02</strong><span>Design with a builder&apos;s instinct</span></div>
              <div><strong>03</strong><span>Systems made to keep moving</span></div>
            </div>
          </div>
          <div className="statement-signal" aria-hidden="true"><Sparkles size={20} strokeWidth={1.2} /><span>Design<br />with<br />intent</span></div>
        </section>

        <section className="work-section section-shell reveal-on-scroll" id="work">
          <div className="section-heading">
            <div><p className="eyebrow">Selected work <span className="eyebrow-line" /></p><h2>Built to be <em>felt.</em></h2></div>
            <p className="section-note">A small selection of digital experiences, identities, and intelligent systems made for forward-thinking teams.</p>
          </div>
          <div className="work-grid">
            {portfolio.map(item => (
              <article className={`work-card ${item.className}`} key={item.number}>
                <div className="work-image-wrap">
                  <img src={item.image} alt={item.alt} loading="lazy" />
                  <div className="work-image-shade" />
                  <div className="work-number">{item.number}</div>
                  <div className="work-hover"><span>View direction</span><MoveUpRight size={17} /></div>
                </div>
                <div className="work-card-copy">
                  <div><p className="card-eyebrow">{item.eyebrow}</p><h3>{item.title}</h3></div>
                  <p>{item.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="services-section section-shell reveal-on-scroll" id="services">
          <div className="services-heading">
            <div className="statement-index">A<span>—</span>02</div>
            <div><p className="eyebrow">What we do</p><h2>Less, but <em>better.</em></h2></div>
          </div>
          <div className="services-list">
            {services.map(([number, title, copy, service]) => (
              <button className="service-row" key={number} type="button" onClick={() => selectService(service)} aria-label={`Start an inquiry for ${title}`}>
                <span className="service-number">{number}</span>
                <h3>{title}</h3>
                <p>{copy}</p>
                <Plus size={18} strokeWidth={1.2} />
              </button>
            ))}
          </div>
        </section>

        <section className="why-section section-shell reveal-on-scroll" id="why">
          <div className="why-heading">
            <div className="statement-index">A<span>—</span>03</div>
            <div><p className="eyebrow">Why AVNIVO</p><h2>Built for the space between <em>strategy</em> and shipped.</h2></div>
          </div>
          <div className="why-grid">
            <article className="why-card"><span>01</span><h3>One sharp point of view</h3><p>No hand-offs between the idea and the execution. Senior thinking stays close to the work.</p></article>
            <article className="why-card"><span>02</span><h3>Technology with taste</h3><p>We use modern tools to make experiences clearer, faster, and more useful—not louder.</p></article>
            <article className="why-card"><span>03</span><h3>Made for real momentum</h3><p>Every system is designed to launch cleanly, learn quickly, and give your team leverage.</p></article>
            <article className="why-card"><span>04</span><h3>Trust in the details</h3><p>Thoughtful communication, considered craft, and dependable delivery from first brief to final build.</p></article>
          </div>
        </section>

        <section className="manifesto section-shell reveal-on-scroll">
          <div className="manifesto-art" aria-hidden="true"><div className="manifesto-ring" /><div className="manifesto-core" /><div className="manifesto-cross manifesto-cross--one" /><div className="manifesto-cross manifesto-cross--two" /></div>
          <div className="manifesto-copy"><p className="eyebrow">The AVNIVO principle</p><blockquote>&ldquo;Technology is most beautiful when you stop noticing it.&rdquo;</blockquote><p>We make the invisible feel considered—from the first interaction to the last detail.</p></div>
        </section>

        <section className="contact-section section-shell reveal-on-scroll" id="contact">
          <div className="contact-top"><p className="eyebrow">Have a good one?</p><span>Let&apos;s make it real.</span></div>
          <a className="contact-link" href="mailto:avnivocreative@gmail.com">avnivocreative@gmail.com <ArrowUpRight size={30} strokeWidth={1.1} /></a>
          <div className="contact-form-intro">
            <div><p className="eyebrow">Project intake</p><h3>Tell us what you&apos;re building.</h3></div>
            <p>Share the outline. We&apos;ll bring the questions, the point of view, and a considered next step.</p>
          </div>
          <div className="contact-trust"><span>Private by default</span><span>Senior-led from brief to build</span><span>Usually replying within 48 hours</span></div>
          <form className="contact-form" id="contact-form" onSubmit={handleSubmit}>
            <div className="form-grid">
              <label className="form-field"><span>Name</span><input id="contact-name" name="name" type="text" autoComplete="name" value={form.name} onChange={event => setField("name", event.target.value)} required minLength={2} maxLength={120} /></label>
              <label className="form-field"><span>Email</span><input name="email" type="email" autoComplete="email" value={form.email} onChange={event => setField("email", event.target.value)} required maxLength={320} /></label>
              <label className="form-field"><span>Company <small>Optional</small></span><input name="company" type="text" autoComplete="organization" value={form.company} onChange={event => setField("company", event.target.value)} maxLength={160} /></label>
              <label className="form-field"><span>What do you need?</span><select name="service" value={form.service} onChange={event => setField("service", event.target.value as Service)}>{serviceOptions.map(option => <option key={option} value={option}>{option}</option>)}</select></label>
              <label className="form-field form-field--wide"><span>Project outline</span><textarea name="message" rows={5} value={form.message} onChange={event => setField("message", event.target.value)} required minLength={20} maxLength={5000} placeholder="A little context goes a long way." /></label>
              <input className="contact-honeypot" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" value={form.website} onChange={event => setField("website", event.target.value)} />
            </div>
            <div className="form-actions">
              <p className={`form-status form-status--${submitState}`} aria-live="polite">
                {submitState === "success" && <>Received{referenceCode ? ` — ${referenceCode}` : ""}. We&apos;ll be in touch soon.</>}
                {submitState === "error" && <>Something interrupted the send. Please try again or email avnivocreative@gmail.com.</>}
                {submitState === "idle" && "Your details stay with AVNIVO."}
              </p>
              <button className="form-submit" type="submit" disabled={submitInquiry.isPending}>{submitInquiry.isPending ? "Sending..." : "Send enquiry"}<ArrowUpRight size={17} /></button>
            </div>
          </form>
          <div className="contact-bottom"><span>New business / collaborations</span><span>Usually replying within 48 hours</span></div>
        </section>
      </main>

      <footer className="avnivo-footer">
          <a className="wordmark" href="#top"><span className="wordmark-mark" aria-hidden="true"><span /><span /><span /></span><span className="wordmark-name">AVNIVO</span></a>
        <span>Creative digital &amp; AI studio</span>
        <span>© 2024 — 2025</span>
      </footer>
    </div>
  );
}
