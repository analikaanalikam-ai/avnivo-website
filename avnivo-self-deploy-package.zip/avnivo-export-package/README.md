# AVNIVO — Self-Deployable Production Package

AVNIVO is a premium dark cinematic creative-technology studio website built with React, Vite, Express, tRPC, Drizzle ORM, and MySQL-compatible persistence.

This package includes the complete source, local copies of the five portfolio visuals, database migrations, Docker deployment files, and the configuration needed to self-host it on another provider.

## What is included

- React/Vite frontend with the existing AVNIVO visual system and interactions
- Express + tRPC backend
- Working contact enquiry form with validation, honeypot protection, origin checks, rate limiting, and database persistence
- Drizzle schema and checked-in MySQL migrations
- Bundled image assets in `client/public/assets/`
- `Dockerfile` and `docker-compose.yml`
- `.env.example` with safe placeholders only
- `docker-entrypoint.sh` to apply migrations before startup
- Production build scripts and tests

## Requirements

- Node.js 22+
- pnpm 10.18+
- MySQL 8+ or a compatible MariaDB provider
- A hosting provider that can run a long-lived Node.js process or Docker container

## Option A: Docker Compose

1. Copy the environment template:

   ```bash
   cp .env.example .env
   ```

2. Set strong values in `.env`. At minimum, set:

   - `MANUS_JWT_SECRET`: a long random secret
   - `MYSQL_PASSWORD`: a strong database password
   - `MYSQL_ROOT_PASSWORD`: a separate strong root password

3. Start the application and database:

   ```bash
   docker compose up -d --build
   ```

4. Verify the app:

   ```bash
   curl http://localhost:3000/api/health
   ```

   Expected response:

   ```json
   {"status":"ok"}
   ```

The app listens on port `3000` inside the container. Change the public port with `APP_PORT=8080 docker compose up -d` if required by your host.

## Option B: Node.js process + managed MySQL

1. Install dependencies:

   ```bash
   pnpm install --frozen-lockfile
   ```

2. Create `.env` from `.env.example` and set a provider-specific `DATABASE_URL`, for example:

   ```env
   NODE_ENV=production
   PORT=3000
   DATABASE_URL=mysql://user:password@your-mysql-host:3306/avnivo
   MANUS_JWT_SECRET=replace-with-a-long-random-secret
   ```

3. Apply migrations:

   ```bash
   pnpm db:migrate
   ```

4. Build and start:

   ```bash
   pnpm build
   pnpm start
   ```

5. Put your hosting provider's HTTPS reverse proxy or managed domain in front of port `3000`.

## Development

```bash
pnpm install --frozen-lockfile
cp .env.example .env
pnpm dev
```

Useful checks:

```bash
pnpm check
pnpm test --run
pnpm build
```

## Environment variables

`DATABASE_URL` and `MANUS_JWT_SECRET` are required for the backend contact flow. The `MANUS_*` API/OAuth values are optional integrations retained for compatibility with the original project. The public website and enquiry persistence work without them when self-hosted.

If you leave the optional Manus API values blank, enquiry records still persist in MySQL. The optional owner notification helper will log a warning instead of sending a message. To receive email notifications on a non-Manus host, connect the persisted `contact_inquiries` records to your provider's SMTP, transactional-email, or webhook service; no credentials are included in this package.

## Database and contact form

- Schema: `drizzle/schema.ts`
- Migrations: `drizzle/*.sql`
- Public API: `contact.submit` through `/api/trpc`
- Protected listing: `contact.list` through `/api/trpc`
- Health check: `GET /api/health`

The form stores name, email, company, selected service, message, source, hashed IP, reference code, status, and timestamps. Do not expose the database directly to the browser.

## GoDaddy custom domain connection

The correct DNS target depends on the hosting provider you choose. There is no universal AVNIVO IP address or CNAME target in this source package.

1. Deploy the app and obtain the host's assigned domain, static IP, or CNAME target.
2. In GoDaddy, open **Domains → DNS → Manage DNS** for `avnivotech.com`.
3. For the apex domain (`@`), use the hosting provider's required **A**, **ALIAS**, or **ANAME** record. Do not guess an IP address.
4. For `www`, create a **CNAME** pointing to the exact target supplied by the host.
5. Remove conflicting old A/CNAME records only after confirming they belong to the previous host.
6. Add both `avnivotech.com` and `www.avnivotech.com` in the hosting provider's custom-domain panel.
7. Wait for DNS propagation, then enable the host's managed HTTPS certificate.
8. Confirm both URLs and the form endpoint over HTTPS.

The DNS records are controlled by the hosting provider, not by the website source code. Use that provider's official DNS values and TLS instructions.

## Production notes

- Do not commit `.env` or any secret values.
- Use a managed MySQL database or persistent Docker volume for production data.
- Back up the database before migrations or provider moves.
- Configure firewall rules so MySQL is not publicly exposed.
- Use HTTPS before accepting contact enquiries.
- Keep the existing image files in `client/public/assets/`; the frontend now references local assets and does not depend on Manus storage paths.
- The old `app.config.ts` logo metadata is harmless outside Manus; the website itself does not require it to run.
