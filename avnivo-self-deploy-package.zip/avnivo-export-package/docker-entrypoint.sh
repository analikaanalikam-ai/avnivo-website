#!/bin/sh
set -eu

printf '%s\n' 'Applying database migrations...'
pnpm db:migrate
printf '%s\n' 'Starting AVNIVO...'
exec node dist/index.js
