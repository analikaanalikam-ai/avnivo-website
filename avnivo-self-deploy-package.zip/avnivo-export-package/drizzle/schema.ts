import { index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const contactInquiries = mysqlTable(
  "contact_inquiries",
  {
    id: int("id").autoincrement().primaryKey(),
    referenceCode: varchar("referenceCode", { length: 20 }).notNull().unique(),
    name: varchar("name", { length: 120 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    company: varchar("company", { length: 160 }),
    service: mysqlEnum("service", [
      "Web experiences",
      "Brand systems",
      "AI-native craft",
      "Automation systems",
      "Product strategy",
      "Creative solutions",
      "Not sure yet",
    ]).notNull(),
    message: text("message").notNull(),
    status: mysqlEnum("status", ["new", "in_progress", "closed"]).default("new").notNull(),
    source: varchar("source", { length: 64 }).default("website").notNull(),
    ipHash: varchar("ipHash", { length: 64 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    createdAtIdx: index("contact_inquiries_created_at_idx").on(table.createdAt),
    ipHashIdx: index("contact_inquiries_ip_hash_idx").on(table.ipHash),
  }),
);

export type ContactInquiry = typeof contactInquiries.$inferSelect;
export type InsertContactInquiry = typeof contactInquiries.$inferInsert;
