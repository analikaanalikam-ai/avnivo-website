CREATE TABLE `contact_inquiries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referenceCode` varchar(20) NOT NULL,
	`name` varchar(120) NOT NULL,
	`email` varchar(320) NOT NULL,
	`company` varchar(160),
	`service` enum('Web experiences','Brand systems','AI-native craft','Creative solutions','Not sure yet') NOT NULL,
	`message` text NOT NULL,
	`status` enum('new','in_progress','closed') NOT NULL DEFAULT 'new',
	`source` varchar(64) NOT NULL DEFAULT 'website',
	`ipHash` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contact_inquiries_id` PRIMARY KEY(`id`),
	CONSTRAINT `contact_inquiries_referenceCode_unique` UNIQUE(`referenceCode`)
);
--> statement-breakpoint
CREATE INDEX `contact_inquiries_created_at_idx` ON `contact_inquiries` (`createdAt`);--> statement-breakpoint
CREATE INDEX `contact_inquiries_ip_hash_idx` ON `contact_inquiries` (`ipHash`);